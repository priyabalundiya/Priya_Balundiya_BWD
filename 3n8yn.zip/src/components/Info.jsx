import React from "react";
function Info() {
  return (
    <div className = "note">
      <h1>Javascript and React.js</h1>
      <p>
        A basic web dev React Js Bootcamp
      </p>
    </div>
  );
}

export default Info;
